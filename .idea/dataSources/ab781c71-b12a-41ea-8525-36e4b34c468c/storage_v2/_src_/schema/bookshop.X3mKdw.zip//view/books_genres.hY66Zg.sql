create definer = root@localhost view books_genres as
select `bookshop`.`books`.`id`          AS `id`,
       `bookshop`.`books`.`title`       AS `title`,
       `bookshop`.`books`.`author_id`   AS `author_id`,
       `bookshop`.`books`.`price`       AS `price`,
       `bookshop`.`books`.`description` AS `description`,
       `bookshop`.`books`.`photo_link`  AS `photo_link`,
       `g`.`id`                         AS `genre_id`,
       `g`.`name`                       AS `name`
from ((`bookshop`.`books` join `bookshop`.`genre_books` `gb` on ((`gb`.`book_id` = `bookshop`.`books`.`id`)))
         join `bookshop`.`genres` `g` on ((`gb`.`genre_id` = `g`.`id`)));

