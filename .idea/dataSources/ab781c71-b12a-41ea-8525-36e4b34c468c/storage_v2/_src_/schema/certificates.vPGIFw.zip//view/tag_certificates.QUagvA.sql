create definer = root@localhost view tag_certificates as
select `certificates`.`tag`.`id`   AS `id`,
       `certificates`.`tag`.`name` AS `name`,
       `c`.`id`                    AS `certificate_id`,
       `c`.`name`                  AS `certificate_name`,
       `c`.`price`                 AS `price`,
       `c`.`description`           AS `description`,
       `c`.`duration`              AS `duration`,
       `c`.`create_date`           AS `create_date`,
       `c`.`last_update_day`       AS `last_update_day`
from ((`certificates`.`tag` left join `certificates`.`certificate_tag` `ct` on ((`ct`.`tag_id` = `certificates`.`tag`.`id`)))
         left join `certificates`.`certificate` `c` on ((`c`.`id` = `ct`.`certificate_id`)));

