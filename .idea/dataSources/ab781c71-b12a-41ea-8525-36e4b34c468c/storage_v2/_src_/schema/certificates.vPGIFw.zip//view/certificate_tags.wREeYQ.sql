create definer = root@localhost view certificate_tags as
select `c`.`id`                    AS `certificate_id`,
       `c`.`name`                  AS `certificate_name`,
       `c`.`price`                 AS `price`,
       `c`.`description`           AS `description`,
       `c`.`duration`              AS `duration`,
       `c`.`create_date`           AS `create_date`,
       `c`.`last_update_day`       AS `last_update_day`,
       `certificates`.`tag`.`id`   AS `tag_id`,
       `certificates`.`tag`.`name` AS `tag_name`
from ((`certificates`.`certificate` `c` left join `certificates`.`certificate_tag` `ct` on ((`ct`.`tag_id` = `c`.`id`)))
         left join `certificates`.`tag` on ((`certificates`.`tag`.`id` = `ct`.`certificate_id`)));

